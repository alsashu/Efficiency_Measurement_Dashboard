import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router"; // CLI imports router
import { LogInPageComponent } from "./components/pages/login-page/logIn-page.component";
import { MainPageComponent } from "./components/pages/main-page/main-page.component";
import { UserInfoPageComponent } from "./components/pages/userInfo-page/userInfo-page.component";
import { MainPageDeactivateGuard } from "./guards/main-page-deactivate.guard";

const routes: Routes = [
  { path: "", component: LogInPageComponent },
  { path: "main", component: MainPageComponent, canDeactivate: [MainPageDeactivateGuard] },
  { path: "user-info", component: UserInfoPageComponent },
];

// configures NgModule imports and exports
@NgModule({
  imports: [RouterModule.forRoot(routes, {})],
  exports: [RouterModule],
})
export class AppRoutingModule {}
