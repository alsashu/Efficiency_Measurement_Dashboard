import { Component, OnInit } from "@angular/core";
import { IViewService } from "../../../services/view/view.service";
import { IApiService } from "src/app/services/api/api.service";
import { IWebsocketService } from "src/app/services/websocket/websocket.service";
import { ServicesService } from "src/app/services/services/services.service";
import { ICommandService } from "src/app/common/services/command/command.service";
import { ServicesConst } from "src/app/services/services/services.const";
import { Router } from "@angular/router";
import { IUserService } from "src/app/services/user/user.service";
import { ITranslateService } from "src/app/services/translate/translate.service";
import { IAppConfigService } from "src/app/services/app/app-config.service";
import { IModalViewService } from "src/app/services/modal/imodal-view.service";
import { IAndroidService } from "src/app/services/android/android.service";
import { IModelVerificationService } from "src/app/services/model/model-verification.service";
import { IModelLoadSaveService } from "src/app/services/model/model-load-save.service";
import { IMessageService } from "src/app/services/message/message.service";

@Component({
  selector: "app-navbar",
  templateUrl: "./navbar.component.html",
  styleUrls: ["./navbar.component.css"],
  host: { class: "navbar navbar-expand-sm navbar-dark fixed-top" },
})
/**
 * Nav bar component
 */
export class NavbarComponent implements OnInit {
  public isCollapsed = true;

  public serverUrl: string;

  public connectedStatus = $localize`:@@navbar.connected:Connected to server`;
  public notConnectedStatus = $localize`:@@navbar.notConnected:Not connected to server`;
  public offlineStatus = $localize`:@@navbar.offline:Offline`;

  public commandService: ICommandService;
  public viewService: IViewService;
  public apiService: IApiService;
  public websocketService: IWebsocketService;
  public userService: IUserService;
  public translateService: ITranslateService;
  public modalViewService: IModalViewService;
  public androidService: IAndroidService;
  public appConfigService: IAppConfigService;
  public modelVerificationService: IModelVerificationService;
  private modelLoadSaveService: IModelLoadSaveService;
  private messageService: IMessageService;

  /**
   * Constructor
   * @param servicesService The services service
   * @param router The router
   */
  constructor(public servicesService: ServicesService, public router: Router) {}

  /**
   * Init
   */
  public ngOnInit() {
    this.commandService = this.servicesService.getService(ServicesConst.CommandService) as ICommandService;
    this.viewService = this.servicesService.getService(ServicesConst.ViewService) as IViewService;
    this.apiService = this.servicesService.getService(ServicesConst.ApiService) as IApiService;
    this.websocketService = this.servicesService.getService(ServicesConst.WebsocketService) as IWebsocketService;
    this.translateService = this.servicesService.getService(ServicesConst.TranslateService) as ITranslateService;
    this.modalViewService = this.servicesService.getService(ServicesConst.ModalViewService) as IModalViewService;
    this.userService = this.servicesService.getService(ServicesConst.UserService) as IUserService;
    this.androidService = this.servicesService.getService(ServicesConst.AndroidService) as IAndroidService;
    this.appConfigService = this.servicesService.getService(ServicesConst.AppConfigService) as IAppConfigService;

    this.modelVerificationService = this.servicesService.getService(
      ServicesConst.ModelVerificationService
    ) as IModelVerificationService;
    this.modelLoadSaveService = this.servicesService.getService(
      ServicesConst.ModelLoadSaveService
    ) as IModelLoadSaveService;
    this.messageService = this.servicesService.getService(ServicesConst.MessageService) as IMessageService;

    this.serverUrl = this.apiService.serverUrl;
  }

  /**
   * Reset views and related options (e.g. Interval) to defaults.
   * If there are unsaved verification changes, shows confirmation first (same as closing Verification tab).
   */
  public onResetViews(): void {
    if (this.modelVerificationService && this.modelVerificationService.isDirty) {
      this.modalViewService.openMessageModalComponent(
        {
          title: "Unsaved Changes",
          message: "You have unsaved changes. Save before leaving.",
          btnOKLabel: "Yes",
          btnCancelLabel: "No",
        },
        () => {
          this.modelLoadSaveService.saveSelectedProject().subscribe(
            () => {
              this.modelVerificationService.clearDirty();
              this.messageService.addTextMessage("Verification data saved successfully.");
              this.performResetViews();
            },
            (error: any) => {
              console.error("[Verification] Save failed during reset views:", error);
              this.performResetViews();
            }
          );
        },
        () => {
          // User chose not to save - discard dirty state and reset views without saving
          this.modelVerificationService.clearDirty();
          this.performResetViews();
        }
      );
    } else {
      this.performResetViews();
    }
  }

  /**
   * Perform the actual reset of views and interval
   */
  private performResetViews(): void {
    this.viewService.resetConfig(true);
    this.modelVerificationService.setAutoSaveIntervalMinutes(15);
  }

  /**
   * Toggle auto-save enabled/disabled
   */
  public onAutoSaveToggle(): void {
    this.modelVerificationService.setAutoSaveEnabled(!this.modelVerificationService.isAutoSaveEnabled);
  }

  /**
   * Handle auto-save interval change
   * @param event The input event
   */
  public onAutoSaveIntervalChange(event: any): void {
    let value = parseInt(event.target.value, 10);

    if (isNaN(value)) {
      // Restore previous valid value if input is not a number
      value = this.modelVerificationService.autoSaveIntervalMinutes;
    }

    // Clamp between 1 and 60 minutes
    if (value < 1) {
      value = 1;
    } else if (value > 60) {
      value = 60;
    }

    // Reflect clamped value back into the input
    event.target.value = value;

    this.modelVerificationService.setAutoSaveIntervalMinutes(value);
  }

  /**
   * Get server tooltip
   * @returns
   */
  public getServerTooltip(): string {
    let s = "";
    if (this.websocketService.getIsOffLine()) {
      s = this.translateService.translateFromMap(this.offlineStatus);
    } else {
      const status = this.websocketService.isConnected ? this.connectedStatus : this.notConnectedStatus;
      s = this.translateService.translateFromMap(status) + " (" + this.serverUrl + ")";
    }
    return s;
  }
}
