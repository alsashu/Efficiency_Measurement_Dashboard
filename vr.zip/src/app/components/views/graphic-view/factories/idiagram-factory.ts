export interface IDiagramFactory {}
