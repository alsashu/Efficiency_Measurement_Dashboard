import { Injectable } from "@angular/core";
import { CanDeactivate } from "@angular/router";
import { MainPageComponent } from "../components/pages/main-page/main-page.component";
import { ServicesService } from "../services/services/services.service";
import { ServicesConst } from "../services/services/services.const";
import { IUnsavedChangesService } from "../services/unsaved-changes/unsaved-changes.service";

/**
 * Blocks navigation away from the main page when verification data has unsaved changes.
 */
@Injectable({
  providedIn: "root",
})
export class MainPageDeactivateGuard implements CanDeactivate<MainPageComponent> {
  constructor(private servicesService: ServicesService) {}

  public canDeactivate(): Promise<boolean> {
    const unsavedChangesService = this.servicesService.getService(
      ServicesConst.UnsavedChangesService
    ) as IUnsavedChangesService;
    return unsavedChangesService.canDeactivate();
  }
}
